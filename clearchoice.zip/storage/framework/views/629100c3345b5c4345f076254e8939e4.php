<?php $__env->startSection('title', 'Clear-ChoiceJanitorial - Client'); ?>
<?php $__env->startPush('css'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/assets/admin-css/client.css')); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <div class="body-main-content">
        <div class="user-table-section">
            <div class="heading-section">
                <div class="d-flex align-items-center">
                    <div class="mr-auto">
                        <h4 class="heading-title">Client List</h4>
                    </div>
                    <div class="btn-option-info wd50">
                        <div class="search-filter">
                            <div class="row g-2">
                                <div class="col-md-4 pt-2">
                                    <a href="<?php echo e(url('addclient')); ?>" class="add-member-btn me-3">Add Client
                                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16"
                                            fill="currentColor" class="bi bi-person-add" viewBox="0 0 16 16">
                                            <path
                                                d="M12.5 16a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7Zm.5-5v1h1a.5.5 0 0 1 0 1h-1v1a.5.5 0 0 1-1 0v-1h-1a.5.5 0 0 1 0-1h1v-1a.5.5 0 0 1 1 0Zm-2-6a3 3 0 1 1-6 0 3 3 0 0 1 6 0ZM8 7a2 2 0 1 0 0-4 2 2 0 0 0 0 4Z" />
                                            <path
                                                d="M8.256 14a4.474 4.474 0 0 1-.229-1.004H3c.001-.246.154-.986.832-1.664C4.484 10.68 5.711 10 8 10c.26 0 .507.009.74.025.226-.341.496-.65.804-.918C9.077 9.038 8.564 9 8 9c-5 0-6 3-6 4s1 1 1 1h5.256Z" />
                                        </svg>
                                    </a>
                                </div>
                                <div class="col-md-8 d-flex">
                                    <a href="<?php echo e(route('Clients')); ?>" class="m-1 mx-3"><img
                                            src="<?php echo e(asset('public/assets/admin-images/reset-icon.png')); ?>"
                                            style="height: 25px" alt=""></a>
                                    <form action="">
                                        <div class="search-form-group">
                                            <input type="text" name="search" class="form-control" style="width: 165%"
                                                placeholder="Search by Client Name">
                                            <span class="search-icon"><img
                                                    src="<?php echo e(asset('public/assets/admin-images/search-icon.svg')); ?>"></span>

                                            <span class="search-icon"><img
                                                    src="<?php echo e(asset('public/assets/admin-images/search-icon.svg')); ?>"></span>

                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="user-content-section">
                <div class="ccj-card">

                    <div class="table-responsive">
                        <table class="table ccj-table">
                            <thead>
                                <tr>
                                    <th>Date</th>
                                    <th>Client Name</th>
                                    <th>Email</th>
                                    <th>Client Notes</th>
                                    <th>Lead Source</th>
                                    <th>Company</th>
                                    <th>Mobile Number</th>
                                    <th>Work Number</th>
                                    <th>Status</th>
                                    <th style="white-space:nowrap;">Action</th>
                                </tr>
                            </thead>

                            <tbody>
                                <?php if($datas->isEmpty()): ?>
                                    <tr>
                                        <td colspan="11" class="text-center">
                                            No record found
                                        </td>
                                    </tr>
                                <?php elseif(!$datas->isEmpty()): ?>
                                    <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td style="white-space: nowrap;">
                                                <?php echo e(date('M d, Y', strtotime($val->created_at))); ?>

                                            </td>

                                            <td style="white-space: nowrap;">
                                                <?php echo e($val->name); ?>

                                            </td>

                                            <td>
                                                <?php echo e($val->email_address); ?>

                                            </td>
                                            <td>
                                                <?php echo e($val->client_notes); ?>

                                            </td>


                                            <td>
                                                <?php echo e($val->lead_source); ?>

                                            </td>
                                            <td>
                                                <?php echo e($val->company); ?>

                                            </td>
                                            <td>
                                                <?php echo e($val->mobile_number); ?>

                                            </td>
                                            <td style="white-space: nowrap;">
                                                <?php echo e($val->client_work_number); ?>

                                            </td>
                                            <td>
                                                <span class="status-text grstatus">
                                                    <?php if($val->status == 1): ?>
                                                        Active
                                                    <?php else: ?>
                                                        Inactive
                                                    <?php endif; ?>
                                                </span>
                                            </td>
                                            <td style="white-space:nowrap;">
                                                <a class="viewbtn"
                                                    href="<?php echo e(url('client-details/' . encryptDecrypt('encrypt', $val->id))); ?>">
                                                    <img src="<?php echo e(asset('public/assets/admin-images/view-icon.svg')); ?>">
                                                </a>
                                                <a class="viewbtn"
                                                    href="<?php echo e(url('edit-client/' . encryptDecrypt('encrypt', $val->id))); ?>') }}">
                                                    <img src="<?php echo e(asset('public/assets/admin-images/edit-icon.svg')); ?>">
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                                <div class="d-flex justify-content-left">
                                    <?php echo e($datas->links('pagination::bootstrap-4')); ?>

                                </div>
                            </tbody>
                        </table>
                    </div>
                    
                </div>
            </div>
        </div>
    </div>

    <!-- --------------Add team Member modal------------- -->
    <div class="modal fade" id="addTeamMember" aria-hidden="true" aria-labelledby="exampleModalToggleLabel" tabindex="-1">

        <div class="modal fade" id="addTeamMember" aria-hidden="true" aria-labelledby="exampleModalToggleLabel"
            tabindex="-1">

            <div class="modal-dialog modal-xl  modal-dialog-scrollable">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <h5 class="text-center"><svg xmlns="http://www.w3.org/2000/svg" width="26" height="26"
                                fill="currentColor" class="bi bi-plus-circle-fill me-2" viewBox="0 0 16 16">
                                <path
                                    d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zM8.5 4.5a.5.5 0 0 0-1 0v3h-3a.5.5 0 0 0 0 1h3v3a.5.5 0 0 0 1 0v-3h3a.5.5 0 0 0 0-1h-3v-3z" />
                            </svg>Add Client </h5>
                        <form action="<?php echo e(route('SaveClient')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-floating mb-3">
                                        <input type="text" class="form-control" id="floatingInput" name="first_name"
                                            placeholder="First name" value="<?php echo e(old('first_name')); ?>" required>
                                        <label for="floatingInput" class="text-capitalize">First name</label>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-floating mb-3">
                                        <input type="text" class="form-control" id="floatingInput" name="last_name"
                                            placeholder="Last name" value="<?php echo e(old('last_name')); ?>" required>
                                        <label for="floatingInput" class="text-capitalize">Last name</label>

                                        <input type="text" class="form-control" id="floatingInput" name="name"
                                            placeholder="Full name" value="<?php echo e(old('name')); ?>" required>
                                        <label for="floatingInput" class="text-capitalize">Full name</label>


                                        <input type="text" class="form-control" id="floatingInput" name="name"
                                            placeholder="Full name" value="<?php echo e(old('name')); ?>" required>
                                        <label for="floatingInput" class="text-capitalize">Full name</label>

                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-floating mb-3">
                                        <input type="email" class="form-control" id="floatingInput" name="email"
                                            placeholder="Enter email Id" value="<?php echo e(old('email')); ?>" required>
                                        <label for="floatingInput" class="text-capitalize">Email Id</label>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-floating mb-3">
                                        <input type="tel" class="form-control" id="floatingInput"
                                            name="mobile_number" placeholder="Enter phone Number"
                                            value="<?php echo e(old('mobile_number')); ?>" required>
                                        <label for="floatingInput" class="text-capitalize">Phone Number</label>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <h4 class="subhead-modal mb-2">Address</h4>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-floating mb-3">
                                        <textarea class="form-control" placeholder="Leave a comment here" id="floatingTextarea" name="address"
                                            rows="4" required></textarea>
                                        <label for="floatingTextarea" class="text-capitalize">Street Address</label>
                                    </div>
                                </div>
                                <div class="fixed-modal-footer modal-footer justify-content-center mt-5 ">
                                    <div class="modal-footer justify-content-center">
                                        <div class="text-center">
                                            <button href="#" class="btn save-account" data-bs-toggle="modal"
                                                data-bs-target="#createTeamMemberAccount" type="submit">Save & Create
                                                Team
                                                Members Account</button>
                                            <p class="mt-2 mb-0 pb-0">Or</p>
                                            <a href="#" class="send-link text-capitalize"
                                                data-bs-target="#sendLinkTo" data-bs-toggle="modal"
                                                data-bs-dismiss="modal">Send <svg xmlns="http://www.w3.org/2000/svg"
                                                    width="16" height="16" fill="currentColor"
                                                    class="bi bi-link-45deg" viewBox="0 0 16 16">
                                                    <path
                                                        d="M4.715 6.542 3.343 7.914a3 3 0 1 0 4.243 4.243l1.828-1.829A3 3 0 0 0 8.586 5.5L8 6.086a1.002 1.002 0 0 0-.154.199 2 2 0 0 1 .861 3.337L6.88 11.45a2 2 0 1 1-2.83-2.83l.793-.792a4.018 4.018 0 0 1-.128-1.287z" />
                                                    <path
                                                        d="M6.586 4.672A3 3 0 0 0 7.414 9.5l.775-.776a2 2 0 0 1-.896-3.346L9.12 3.55a2 2 0 1 1 2.83 2.83l-.793.792c.112.42.155.855.128 1.287l1.372-1.372a3 3 0 1 0-4.243-4.243L6.586 4.672z" />
                                                </svg>Link to Download app on team member registered Email id</a>
                                        </div>
                                    </div>
                                </div>

                                <textarea class="form-control" placeholder="Leave a comment here" id="floatingTextarea" name="address"
                                    rows="4" required></textarea>
                                <label for="floatingTextarea" class="text-capitalize">Street Address</label>
                            </div>
                    </div>
                    <div class="fixed-modal-footer modal-footer justify-content-center mt-5 ">
                        <div class="modal-footer justify-content-center">
                            <div class="text-center">
                                <button href="#" class="btn save-account" data-bs-toggle="modal"
                                    data-bs-target="#createTeamMemberAccount" type="submit">Save & Create Team Members
                                    Account</button>
                                <p class="mt-2 mb-0 pb-0">Or</p>
                                <a href="#" class="send-link text-capitalize" data-bs-target="#sendLinkTo"
                                    data-bs-toggle="modal" data-bs-dismiss="modal">Send <svg
                                        xmlns="http://www.w3.org/2000/svg" width="16" height="16"
                                        fill="currentColor" class="bi bi-link-45deg" viewBox="0 0 16 16">
                                        <path
                                            d="M4.715 6.542 3.343 7.914a3 3 0 1 0 4.243 4.243l1.828-1.829A3 3 0 0 0 8.586 5.5L8 6.086a1.002 1.002 0 0 0-.154.199 2 2 0 0 1 .861 3.337L6.88 11.45a2 2 0 1 1-2.83-2.83l.793-.792a4.018 4.018 0 0 1-.128-1.287z" />
                                        <path
                                            d="M6.586 4.672A3 3 0 0 0 7.414 9.5l.775-.776a2 2 0 0 1-.896-3.346L9.12 3.55a2 2 0 1 1 2.83 2.83l-.793.792c.112.42.155.855.128 1.287l1.372-1.372a3 3 0 1 0-4.243-4.243L6.586 4.672z" />
                                    </svg>Link to Download app on team member registered Email id</a>
                            </div>
                        </div>
                    </div>

                    </form>
                </div>
            </div>
        </div>
    </div>

    <!------- Save & Create Team Members account modal --------->
    <div class="modal fade" id="createTeamMemberAccount" tabindex="-1" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <h5 class="text-center">New Team Member <br>Added Successful</h5>
                    <img src="images/employees.svg" alt="image" class="img-fluid modal-img">
                </div>
                <div class="text-center">
                    <a href="#" class="btn save-account">Send <svg xmlns="http://www.w3.org/2000/svg"
                            width="16" height="16" fill="currentColor" class="bi bi-link-45deg"
                            viewBox="0 0 16 16">
                            <path
                                d="M4.715 6.542 3.343 7.914a3 3 0 1 0 4.243 4.243l1.828-1.829A3 3 0 0 0 8.586 5.5L8 6.086a1.002 1.002 0 0 0-.154.199 2 2 0 0 1 .861 3.337L6.88 11.45a2 2 0 1 1-2.83-2.83l.793-.792a4.018 4.018 0 0 1-.128-1.287z" />
                            <path
                                d="M6.586 4.672A3 3 0 0 0 7.414 9.5l.775-.776a2 2 0 0 1-.896-3.346L9.12 3.55a2 2 0 1 1 2.83 2.83l-.793.792c.112.42.155.855.128 1.287l1.372-1.372a3 3 0 1 0-4.243-4.243L6.586 4.672z" />
                        </svg>Link to Download App</a>
                    <p class="text-capitalize send-link mt-2 mb-5">With created password on employee registered email
                        id
                    </p>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dlayy048i7m0/public_html/clearchoice-janitorial/resources/views/admin/client.blade.php ENDPATH**/ ?>