<?php $__env->startSection('title', 'Clear-ChoiceJanitorial - Client'); ?>
<?php $__env->startPush('css'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/assets/admin-css/client.css')); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <div class="body-main-content">
        <div class="user-table-section">
            <div class="heading-section">
                <div class="d-flex align-items-center">
                    <div class="mr-auto">
                        <h4 class="heading-title">Client List</h4>
                    </div>
                    <div class="btn-option-info wd40">
                        <div class="search-filter">
                            <div class="row g-2">
                                <div class="col-md-12">
                                    <div class="search-form-group">
                                        <input type="text" name="" class="form-control"
                                            placeholder="Search by client Name, Date, Location, or Status">
                                        <span class="search-icon"><img src="<?php echo e(asset('public/assets/admin-images/search-icon.svg')); ?>"></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="user-content-section">
                <div class="ccj-card">

                    <div class="table-responsive">
                        <table class="table ccj-table">
                            <thead>
                                <tr>
                                    <th>Date</th>
                                    <th>Client Name</th>
                                    <th>Client Address</th>
                                    <th>Lead Source</th>
                                    <th>Amount</th>
                                    <th>Status</th>
                                    <th>Note</th>
                                    <th>Employee Assigned</th>
                                    <th>Action</th>
                                </tr>
                            </thead>

                            <tbody>
                                <tr>
                                    <td style="white-space: nowrap;">
                                        13 sep 2023
                                    </td>

                                    <td style="white-space: nowrap;">
                                        Jesselina Tony
                                    </td>

                                    <td>
                                        5331 Rexford Court, Montgomery AL 36116
                                    </td>

                                    <td>
                                        N/A
                                    </td>

                                    <td>
                                        $300.00
                                    </td>

                                    <td>
                                        <span class="status-text grstatus">Scheduled</span>
                                    </td>
                                    <td>
                                        Cleaning Will Required Space Clear & Cleaning Materials
                                    </td>
                                    <td style="white-space: nowrap;">
                                        John Doe +12 Employee
                                    </td>
                                    <td>
                                        <a class="viewbtn" href="<?php echo e(url('/client-details')); ?>">
                                            <img src="<?php echo e(asset('public/assets/admin-images/view-icon.svg')); ?>">
                                        </a>
                                    </td>
                                </tr>
                                <tr>
                                    <td style="white-space: nowrap;">
                                        13 sep 2023
                                    </td>

                                    <td style="white-space: nowrap;">
                                        Jesselina Tony
                                    </td>

                                    <td>
                                        5331 Rexford Court, Montgomery AL 36116
                                    </td>

                                    <td>
                                        N/A
                                    </td>

                                    <td>
                                        $300.00
                                    </td>

                                    <td>
                                        <span class="status-text grstatus">Scheduled</span>
                                    </td>
                                    <td>
                                        Cleaning Will Required Space Clear & Cleaning Materials
                                    </td>
                                    <td style="white-space: nowrap;">
                                        John Doe +12 Employee
                                    </td>
                                    <td>
                                        <a class="viewbtn" href="<?php echo e(url('/client-details')); ?>">
                                            <img src="<?php echo e(asset('public/assets/admin-images/view-icon.svg')); ?>">
                                        </a>
                                    </td>
                                </tr>
                                <tr>
                                    <td style="white-space: nowrap;">
                                        13 sep 2023
                                    </td>

                                    <td style="white-space: nowrap;">
                                        Jesselina Tony
                                    </td>

                                    <td>
                                        5331 Rexford Court, Montgomery AL 36116
                                    </td>

                                    <td>
                                        N/A
                                    </td>

                                    <td>
                                        $300.00
                                    </td>

                                    <td>
                                        <span class="status-text grstatus">Scheduled</span>
                                    </td>
                                    <td>
                                        Cleaning Will Required Space Clear & Cleaning Materials
                                    </td>
                                    <td style="white-space: nowrap;">
                                        John Doe +12 Employee
                                    </td>
                                    <td>
                                        <a class="viewbtn" href="<?php echo e(url('/client-details')); ?>">
                                            <img src="<?php echo e(asset('public/assets/admin-images/view-icon.svg')); ?>">
                                        </a>
                                    </td>
                                </tr>
                                <tr>
                                    <td style="white-space: nowrap;">
                                        13 sep 2023
                                    </td>

                                    <td style="white-space: nowrap;">
                                        Jesselina Tony
                                    </td>

                                    <td>
                                        5331 Rexford Court, Montgomery AL 36116
                                    </td>

                                    <td>
                                        N/A
                                    </td>

                                    <td>
                                        $300.00
                                    </td>

                                    <td>
                                        <span class="status-text grstatus">Unscheduled</span>
                                    </td>
                                    <td>
                                        Cleaning Will Required Space Clear & Cleaning Materials
                                    </td>
                                    <td style="white-space: nowrap;">
                                        John Doe +12 Employee
                                    </td>
                                    <td>
                                        <a class="viewbtn" href="<?php echo e(url('/client-details')); ?>">
                                            <img src="<?php echo e(asset('public/assets/admin-images/view-icon.svg')); ?>">
                                        </a>
                                    </td>
                                </tr>
                                <tr>
                                    <td style="white-space: nowrap;">
                                        13 sep 2023
                                    </td>

                                    <td style="white-space: nowrap;">
                                        Jesselina Tony
                                    </td>

                                    <td>
                                        5331 Rexford Court, Montgomery AL 36116
                                    </td>

                                    <td>
                                        N/A
                                    </td>

                                    <td>
                                        $300.00
                                    </td>

                                    <td>
                                        <span class="status-text grstatus">Scheduled</span>
                                    </td>
                                    <td>
                                        Cleaning Will Required Space Clear & Cleaning Materials
                                    </td>
                                    <td style="white-space: nowrap;">
                                        John Doe +12 Employee
                                    </td>
                                    <td>
                                        <a class="viewbtn" href="<?php echo e(url('/client-details')); ?>">
                                            <img src="<?php echo e(asset('public/assets/admin-images/view-icon.svg')); ?>">
                                        </a>
                                    </td>
                                </tr>
                                <tr>
                                    <td style="white-space: nowrap;">
                                        13 sep 2023
                                    </td>

                                    <td style="white-space: nowrap;">
                                        Jesselina Tony
                                    </td>

                                    <td>
                                        5331 Rexford Court, Montgomery AL 36116
                                    </td>

                                    <td>
                                        N/A
                                    </td>

                                    <td>
                                        $300.00
                                    </td>

                                    <td>
                                        <span class="status-text grstatus">Unscheduled</span>
                                    </td>
                                    <td>
                                        Cleaning Will Required Space Clear & Cleaning Materials
                                    </td>
                                    <td style="white-space: nowrap;">
                                        John Doe +12 Employee
                                    </td>
                                    <td>
                                        <a class="viewbtn" href="<?php echo e(url('/client-details')); ?>">
                                            <img src="<?php echo e(asset('public/assets/admin-images/view-icon.svg')); ?>">
                                        </a>
                                    </td>
                                </tr>



                            </tbody>
                        </table>
                    </div>
                    <div class="ccj-table-pagination">
                        <ul class="ccj-pagination">
                            <li class="disabled" id="example_previous">
                                <a href="#" aria-controls="example" data-dt-idx="0" tabindex="0"
                                    class="page-link">Previous</a>
                            </li>
                            <li class="active">
                                <a href="#" class="page-link">1</a>
                            </li>
                            <li class="">
                                <a href="#" aria-controls="example" data-dt-idx="2" tabindex="0"
                                    class="page-link">2</a>
                            </li>
                            <li class="">
                                <a href="#" aria-controls="example" data-dt-idx="3" tabindex="0"
                                    class="page-link">3</a>
                            </li>
                            <li class="next" id="example_next">
                                <a href="#" aria-controls="example" data-dt-idx="7" tabindex="0"
                                    class="page-link">Next</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dlayy048i7m0/public_html/clearchoice-janitorial/resources/views/client.blade.php ENDPATH**/ ?>