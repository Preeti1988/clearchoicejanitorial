<?php $__env->startSection('title', 'Clear Choice Janitorial - Master'); ?>
<?php $__env->startPush('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('public/assets/admin-css/master.css')); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <div class="body-main-content">
        <div class="master-card-contents">
            <div class="master-item-head">
                <div class="master-item-title d-flex align-items-center">
                    <div class="d-flex align-items-center">
                        <div class="master-card-image">
                            <img src="<?php echo e(asset('public/assets/admin-images/master-service.svg')); ?>">
                        </div>
                        <div class="master-card-head">
                            <h2 class="ms-2 mb-0">Service Values</h2>
                        </div>
                    </div>
                </div>
                <div class="add-new-master">
                    <a class="add-new-service-btn" href="#" data-bs-toggle="modal" data-bs-target="#addNewValue">Add
                        New Value</a>
                </div>
            </div>
            <div class="master-item-body">
                <div class="row">
                    <div class="col-md-2 mb-2">
                        <div class="master-list-bg d-flex justify-content-between align-items-center">
                            <p class="mb-0">Vacuum First</p>
                            <div class="cancel-bg">
                                <a href="#"><img src="<?php echo e(asset('public/assets/admin-images/cancel-icon.svg')); ?>" alt=""></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-2 mb-2">
                        <div class="master-list-bg d-flex justify-content-between align-items-center">
                            <p class="mb-0">Dusting</p>
                            <div class="cancel-bg">
                                <a href="#"><img src="<?php echo e(asset('public/assets/admin-images/cancel-icon.svg')); ?>" alt=""></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-2 mb-2">
                        <div class="master-list-bg d-flex justify-content-between align-items-center">
                            <p class="mb-0">Floor Cleaning</p>
                            <div class="cancel-bg">
                                <a href="#"><img src="<?php echo e(asset('public/assets/admin-images/cancel-icon.svg')); ?>" alt=""></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-2 mb-2">
                        <div class="master-list-bg d-flex justify-content-between align-items-center">
                            <p class="mb-0">Desk Cleaning</p>
                            <div class="cancel-bg">
                                <a href="#"><img src="<?php echo e(asset('public/assets/admin-images/cancel-icon.svg')); ?>" alt=""></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-2 mb-2">
                        <div class="master-list-bg d-flex justify-content-between align-items-center">
                            <p class="mb-0">Break Room</p>
                            <div class="cancel-bg">
                                <a href="#"><img src="<?php echo e(asset('public/assets/admin-images/cancel-icon.svg')); ?>" alt=""></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-2 mb-2">
                        <div class="master-list-bg d-flex justify-content-between align-items-center">
                            <p class="mb-0">Food Court Clean</p>
                            <div class="cancel-bg">
                                <a href="#"><img src="<?php echo e(asset('public/assets/admin-images/cancel-icon.svg')); ?>" alt=""></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-2 mb-2">
                        <div class="master-list-bg d-flex justify-content-between align-items-center">
                            <p class="mb-0">Escalator Cleaning</p>
                            <div class="cancel-bg">
                                <a href="#"><img src="<?php echo e(asset('public/assets/admin-images/cancel-icon.svg')); ?>" alt=""></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-2 mb-2">
                        <div class="master-list-bg d-flex justify-content-between align-items-center">
                            <p class="mb-0">Hallways Cleaning</p>
                            <div class="cancel-bg">
                                <a href="#"><img src="<?php echo e(asset('public/assets/admin-images/cancel-icon.svg')); ?>" alt=""></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="master-card-contents">
            <div class="master-item-head">
                <div class="master-item-title d-flex align-items-center">
                    <div class="d-flex align-items-center">
                        <div class="master-card-image">
                            <img src="<?php echo e(asset('public/assets/admin-images/master-designation.svg')); ?>">
                        </div>
                        <div class="master-card-head">
                            <h2 class="ms-2 mb-0">Designation</h2>
                        </div>
                    </div>
                </div>
                <div class="add-new-master">
                    <a class="add-new-service-btn" href="#" data-bs-toggle="modal" data-bs-target="#addNewValue">Add
                        New Value</a>
                </div>
            </div>
            <div class="master-item-body">
                <div class="row">
                    <div class="col-md-2 mb-2">
                        <div class="master-list-bg d-flex justify-content-between align-items-center">
                            <p class="mb-0">Food Technician</p>
                            <div class="cancel-bg">
                                <a href="#"><img src="<?php echo e(asset('public/assets/admin-images/cancel-icon.svg')); ?>" alt=""></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-2 mb-2">
                        <div class="master-list-bg d-flex justify-content-between align-items-center">
                            <p class="mb-0">Service Technician</p>
                            <div class="cancel-bg">
                                <a href="#"><img src="<?php echo e(asset('public/assets/admin-images/cancel-icon.svg')); ?>" alt=""></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-2 mb-2">
                        <div class="master-list-bg d-flex justify-content-between align-items-center">
                            <p class="mb-0">Customer Service</p>
                            <div class="cancel-bg">
                                <a href="#"><img src="<?php echo e(asset('public/assets/admin-images/cancel-icon.svg')); ?>" alt=""></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-2 mb-2">
                        <div class="master-list-bg d-flex justify-content-between align-items-center">
                            <p class="mb-0">Area Lead</p>
                            <div class="cancel-bg">
                                <a href="#"><img src="<?php echo e(asset('public/assets/admin-images/cancel-icon.svg')); ?>" alt=""></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-2 mb-2">
                        <div class="master-list-bg d-flex justify-content-between align-items-center">
                            <p class="mb-0">Superviser</p>
                            <div class="cancel-bg">
                                <a href="#"><img src="<?php echo e(asset('public/assets/admin-images/cancel-icon.svg')); ?>" alt=""></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-2 mb-2">
                        <div class="master-list-bg d-flex justify-content-between align-items-center">
                            <p class="mb-0">Sales Representative</p>
                            <div class="cancel-bg">
                                <a href="#"><img src="<?php echo e(asset('public/assets/admin-images/cancel-icon.svg')); ?>" alt=""></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="master-card-contents">
            <div class="master-item-head">
                <div class="master-item-title d-flex align-items-center">
                    <div class="d-flex align-items-center">
                        <div class="master-card-image">
                            <img src="<?php echo e(asset('public/assets/admin-images/master-marital-status.svg')); ?>">
                        </div>
                        <div class="master-card-head">
                            <h2 class="ms-2 mb-0">Marital Status</h2>
                        </div>
                    </div>
                </div>
                <div class="add-new-master">
                    <a class="add-new-service-btn" href="#" data-bs-toggle="modal"
                        data-bs-target="#addNewValue">Add New Value</a>
                </div>
            </div>
            <div class="master-item-body">
                <div class="row">
                    <div class="col-md-2 mb-2">
                        <div class="master-list-bg d-flex justify-content-between align-items-center">
                            <p class="mb-0">Single</p>
                            <div class="cancel-bg">
                                <a href="#"><img src="<?php echo e(asset('public/assets/admin-images/cancel-icon.svg')); ?>" alt=""></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-2 mb-2">
                        <div class="master-list-bg d-flex justify-content-between align-items-center">
                            <p class="mb-0">Married</p>
                            <div class="cancel-bg">
                                <a href="#"><img src="<?php echo e(asset('public/assets/admin-images/cancel-icon.svg')); ?>" alt=""></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-2 mb-2">
                        <div class="master-list-bg d-flex justify-content-between align-items-center">
                            <p class="mb-0">Separated</p>
                            <div class="cancel-bg">
                                <a href="#"><img src="<?php echo e(asset('public/assets/admin-images/cancel-icon.svg')); ?>" alt=""></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-2 mb-2">
                        <div class="master-list-bg d-flex justify-content-between align-items-center">
                            <p class="mb-0">Divorced</p>
                            <div class="cancel-bg">
                                <a href="#"><img src="<?php echo e(asset('public/assets/admin-images/cancel-icon.svg')); ?>" alt=""></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-2 mb-2">
                        <div class="master-list-bg d-flex justify-content-between align-items-center">
                            <p class="mb-0">Widow</p>
                            <div class="cancel-bg">
                                <a href="#"><img src="<?php echo e(asset('public/assets/admin-images/cancel-icon.svg')); ?>" alt=""></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Modal -->
    <div class="modal fade" id="addNewValue" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1"
        aria-labelledby="staticBackdropLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <h5 class="text-center">Add New Value</h5>
                    <input type="text" class="form-control mt-4" id="value" placeholder="Type here">
                    <div class="text-center">
                        <a class="add-new-value-btn mt-3" href="#">Add</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dlayy048i7m0/public_html/clearchoice-janitorial/resources/views/master.blade.php ENDPATH**/ ?>