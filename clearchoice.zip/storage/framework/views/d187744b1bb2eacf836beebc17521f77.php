<?php $__env->startSection('title', 'Clear-ChoiceJanitorial - Client'); ?>
<?php $__env->startPush('css'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(custom_asset('public/assets/admin-css/home.css')); ?>">
    <link rel="stylesheet" type="text/css"
        href="<?php echo e(custom_asset('public/assets/admin-plugins/OwlCarousel/assets/owl.carousel.min.css')); ?>" />
    <script src="<?php echo e(custom_asset('public/assets/admin-plugins/OwlCarousel/owl.carousel.js')); ?>" type="text/javascript">
    </script>
    <style>
        #search-results {
            position: absolute;
            top: calc(100% - 40px);
            left: 0;
            width: 100%;
            background-color: #fff;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.2);
            z-index: 1000;
            display: none;
        }

        #search-results .result-item {
            padding: 10px;
            border-bottom: 1px solid #ccc;
            cursor: pointer;
        }

        #search-results .result-item:hover {
            background-color: #f0f0f0;
        }
    </style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <div class="body-main-content">
        

        <div class="assign-Services-section">

            <div class="ongoing-Services-section">
                <div class="row">
                    <div class="col-md-12">
                        <div class="services-tabs">
                            <ul class="nav nav-tabs">
                                <li><a href="<?php echo e(route('services.create')); ?>">Create Service</a></li>
                                <li><a class="active" href="#UnAssignedServices" data-bs-toggle="tab"><i
                                            class="las la-eye-slash"></i>
                                        Un-Assigned Services</a>
                                </li>
                            </ul>
                        </div>
                        <div class="Ongoing-calender-list">
                            <div id="Ongoingcalender" class="owl-carousel owl-theme">
                                <?php
                                    $arr = [];
                                    // Get the current month and year
                                    $currentMonth = now()->format('F');
                                    $currentYear = now()->year;

                                    // Get the number of days in the current month
                                    $daysInMonth = date('j');
                                    $currentMonth = date('n'); // n represents the month without leading zeros
                                    $currentYear = date('Y');

                                    // Get the number of days in the current month
                                    $numDaysInMonth = cal_days_in_month(CAL_GREGORIAN, $currentMonth, $currentYear);
                                    // Loop through each day in the month
                                    for ($day = 1; $day <= $numDaysInMonth; $day++) {
                                        $date = now()->setDay($day);
                                        $dayOfWeek = $date->format('D');
                                        $formattedDate = $date->format('d');
                                        $arr[] = ['w' => $dayOfWeek, 'd' => $formattedDate, 'date' => date('Y-m-d', strtotime($date))];
                                    }
                                ?>
                                <?php $__currentLoopData = $arr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <a class="item" href="<?php echo e(route('services.scheduler', 'date=' . $item['date'])); ?>">
                                        <div class="Ongoing-calender-item">
                                            <h3><?php echo e($item['w']); ?></h3>
                                            <h2><?php echo e($item['d']); ?></h2>
                                        </div>
                                    </a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                            </div>
                        </div>
                        <div class="tasks-content-info tab-content">
                            <div class="tab-pane " id="OngoingServices">

                            </div>
                            <div class="tab-pane active" id="UnAssignedServices">
                                <div class="ongoing-services-list">
                                    <?php $__empty_1 = true; $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <div class="ongoing-services-item">
                                            <div class="ongoing-services-item-head">
                                                <div class="ongoing-services-item-title">
                                                    <div class="services-id">#<?php echo e($item->id); ?></div>
                                                    <h2 style="cursor: pointer"
                                                        onclick="location.replace('<?php echo e(route('services.edit', $item->id)); ?>') ">
                                                        Service 1: <?php echo e($item->name); ?></h2>
                                                </div>
                                                <div class="ongoing-services-date">
                                                    <?php echo e(date('l, j M h:i:s A', strtotime($item->created_at))); ?></div>
                                            </div>
                                            <div class="ongoing-services-item-body">
                                                <div class="service-shift-card">
                                                    <div class="service-shift-card-image">
                                                        <img
                                                            src="<?php echo e(custom_asset('public/assets/admin-images/calendar-tick.svg')); ?>">
                                                    </div>
                                                    <div class="service-shift-card-text">
                                                        <h2>Service Shift Timing:</h2>
                                                        <p><?php echo e(date('h:i A', strtotime($item->service_start_time))); ?>

                                                            -<?php echo e(date('h:i A', strtotime($item->service_end_time))); ?></p>
                                                    </div>
                                                </div>

                                                <div class="instructions-text">
                                                    <h3><?php echo e($item->description); ?></h3>
                                                </div>

                                                <div class="row">
                                                    <div class="col-md-4">
                                                        <div class="service-shift-card">
                                                            <div class="service-shift-card-image">
                                                                <img
                                                                    src="<?php echo e(custom_asset('public/assets/admin-images/Qty.svg')); ?>">
                                                            </div>
                                                            <div class="service-shift-card-text">
                                                                <h2>Qty:</h2>
                                                                <p>1</p>
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div class="col-md-4">
                                                        <div class="service-shift-card">
                                                            <div class="service-shift-card-image">
                                                                <img
                                                                    src="<?php echo e(custom_asset('public/assets/admin-images/ServiceFrequency.svg')); ?>">
                                                            </div>
                                                            <div class="service-shift-card-text">
                                                                <h2>Service Frequency:</h2>
                                                                <p><?php echo e($item->frequency); ?></p>
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div class="col-md-4">
                                                        <div class="service-shift-card">
                                                            <div class="service-shift-card-image">
                                                                <img
                                                                    src="<?php echo e(custom_asset('public/assets/admin-images/dollar-circle.svg')); ?>">
                                                            </div>
                                                            <div class="service-shift-card-text">
                                                                <h2>Price</h2>
                                                                <p>$<?php echo e($item->total_service_cost); ?>.00 + Tax Included</p>
                                                            </div>
                                                        </div>
                                                    </div>


                                                </div>
                                            </div>

                                            <div class="ongoing-services-item-foot">
                                                <div class="loaction-address"><img
                                                        src="<?php echo e(custom_asset('public/assets/admin-images/map.svg')); ?>"><?php echo e(isset($item->client->street) ? $item->client->street : ''); ?>

                                                </div>
                                                <div class="ongoing-services-action"><a
                                                        href="<?php echo e(route('services.assign', $item->id)); ?>">Assign Team
                                                        Member</a>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <div class="ongoing-services-item">
                                            <div class="ongoing-services-item-head">
                                                <div class="ongoing-services-item-title">

                                                    <h2>No Services</h2>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endif; ?>

                                </div>
                            </div>
                        </div>
                    </div>


                </div>
            </div>
        </div>

    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dlayy048i7m0/public_html/clearchoice-janitorial/resources/views/admin/services/scheduler.blade.php ENDPATH**/ ?>