<?php $__env->startSection('title', 'Clear-ChoiceJanitorial - Client-Details'); ?>
<?php $__env->startPush('css'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/assets/admin-css/client.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/assets/admin-css/teams.css')); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <div class="body-main-content">
        <div class="client-details-section">
            <div class="client-profile-section">
                <div class="row g-1 align-items-center">
                    <div class="col-md-3">
                        <div class="side-profile-item">
                            <div class="side-profile-media"><img
                                    src="<?php echo e(asset('public/assets/admin-images/user-default.png')); ?>">
                            </div>
                            <div class="side-profile-text">
                                <h2><?php echo e($data->name ?? ''); ?></h2>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-9">
                        <div class="row">
                            <div class="col-md-4">
                                <div class="client-contact-info">
                                    <div class="client-contact-info-icon">
                                        <img src="<?php echo e(asset('public/assets/admin-images/email-icon.svg')); ?>">
                                    </div>
                                    <div class="client-contact-info-content">
                                        <h2>Email Address</h2>
                                        <p><?php echo e($data->email_address ?? ''); ?></p>
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-3">
                                <div class="client-contact-info">
                                    <div class="client-contact-info-icon">
                                        <img src="<?php echo e(asset('public/assets/admin-images/phone-icon.svg')); ?>">
                                    </div>
                                    <div class="client-contact-info-content">
                                        <h2>Phone Number</h2>
                                        <p>+<?php echo e($data->country ? $data->country->phonecode : '1'); ?>

                                            <?php echo e($data->mobile_number ?? ''); ?>

                                        </p>
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-5">
                                <div class="client-contact-info">
                                    <div class="client-contact-info-icon">
                                        <img src="<?php echo e(asset('public/assets/admin-images/map.svg')); ?>">
                                    </div>
                                    <div class="client-contact-info-content">
                                        <h2>Client Default Address</h2>
                                        <p><?php echo e($data->address ?? ''); ?></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


            <div class="ongoing-Services-section">
                <div class="row">
                    <div class="col-md-9">
                        <div class="services-tabs">
                            <ul class="nav nav-tabs">
                                <li><a class="active" href="#OngoingServices" data-bs-toggle="tab">Ongoing</a></li>
                                <li><a href="#UnAssignedServices" data-bs-toggle="tab"> New Request</a></li>
                                <li><a href="#CompletedServices" data-bs-toggle="tab">Completed</a></li>
                            </ul>
                        </div>
                        <div class="Ongoing-calender-list">
                            <div id="Ongoingcalender" class="owl-carousel owl-theme">

                                <?php
                                    $arr = [];
                                    // Get the current month and year
                                    $currentMonth = now()->format('F');
                                    $currentYear = now()->year;

                                    // Get the number of days in the current month
                                    $daysInMonth = date('j');

                                    // Loop through each day in the month
                                    for ($day = 1; $day <= $daysInMonth; $day++) {
                                        $date = now()->setDay($day);
                                        $dayOfWeek = $date->format('D');
                                        $formattedDate = $date->format('d');
                                        $arr[] = ['w' => $dayOfWeek, 'd' => $formattedDate, 'date' => date('Y-m-d', strtotime($date))];
                                    }
                                ?>
                                <?php $__currentLoopData = $arr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <a class="item"
                                        href="<?php echo e(url('client-details/' . encryptDecrypt('encrypt', $data->id) . '?date=' . $item['date'])); ?>">
                                        <div class="Ongoing-calender-item">
                                            <h3><?php echo e($item['w']); ?></h3>
                                            <h2><?php echo e($item['d']); ?></h2>
                                        </div>
                                    </a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                        <div class="tasks-content-info tab-content">
                            <div class="tab-pane active" id="OngoingServices">
                                <div class="ongoing-services-list">
                                    <?php $__empty_1 = true; $__currentLoopData = $ongoing; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <div class="ongoing-services-item">
                                            <div class="ongoing-services-item-head">
                                                <div class="ongoing-services-item-title">
                                                    <div class="services-id">#<?php echo e($item->id); ?></div>
                                                    <h2>Service 1: <?php echo e($item->name); ?></h2>
                                                </div>
                                                <div class="client-info">
                                                    <div class="client-info-icon">
                                                        <?php echo e($item->client ? substr($item->client->name, 0, 1) : 'N/A'); ?>

                                                    </div>
                                                    <div class="client-info-text">
                                                        <?php echo e($item->client ? $item->client->name : 'N/A'); ?>

                                                    </div>
                                                </div>

                                            </div>
                                            <div class="ongoing-services-item-body">
                                                <div class="service-shift-card">
                                                    <div class="service-shift-card-image">
                                                        <img
                                                            src="<?php echo e(asset('public/assets/admin-images/calendar-tick.svg')); ?>">
                                                    </div>
                                                    <div class="service-shift-card-text">
                                                        <h2>Service Shift Timing:</h2>
                                                        <p><?php echo e(date('h:i A', strtotime($item->service_start_time))); ?>

                                                            -<?php echo e(date('h:i A', strtotime($item->service_end_time))); ?>

                                                        </p>
                                                    </div>
                                                </div>

                                                <div class="instructions-text">
                                                    <h3>Primary Instructions: <?php echo e($item->description); ?></h3>
                                                </div>

                                                <div class="row">
                                                    <div class="col-md-4">
                                                        <div class="service-shift-card">
                                                            <div class="service-shift-card-image">
                                                                <img
                                                                    src="<?php echo e(asset('public/assets/admin-images/people.svg')); ?>">
                                                            </div>
                                                            <div class="service-shift-card-text">
                                                                <h2>Job Assigned</h2>
                                                                <p>John Doe + <a
                                                                        href="<?php echo e(route('services.assign', $item->id)); ?>">12
                                                                        Employee</a></p>
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div class="col-md-4">
                                                        <div class="service-shift-card">
                                                            <div class="service-shift-card-image">
                                                                <img
                                                                    src="<?php echo e(asset('public/assets/admin-images/ServiceFrequency.svg')); ?>">
                                                            </div>
                                                            <div class="service-shift-card-text">
                                                                <h2>Service Frequency:</h2>
                                                                <p><?php echo e($item->frequency); ?></p>
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div class="col-md-4">
                                                        <div class="service-shift-card">
                                                            <div class="service-shift-card-image">
                                                                <img
                                                                    src="<?php echo e(asset('public/assets/admin-images/buildings.svg')); ?>">
                                                            </div>
                                                            <div class="service-shift-card-text">
                                                                <h2>Service Type:</h2>
                                                                <p><?php echo e($item->service_type); ?></p>
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div class="col-md-4">
                                                        <div class="service-shift-card">
                                                            <div class="service-shift-card-image">
                                                                <img
                                                                    src="<?php echo e(asset('public/assets/admin-images/clock.svg')); ?>">
                                                            </div>
                                                            <div class="service-shift-card-text">
                                                                <h2>Service Start Time:</h2>
                                                                <p><?php echo e(date('M d,Y', strtotime($item->created_date))); ?>,
                                                                    <?php echo e(date('h:i A', strtotime($item->service_start_time))); ?>

                                                                </p>
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div class="col-md-4">
                                                        <div class="service-shift-card">
                                                            <div class="service-shift-card-image">
                                                                <img
                                                                    src="<?php echo e(asset('public/assets/admin-images/clock.svg')); ?>">
                                                            </div>
                                                            <div class="service-shift-card-text">
                                                                <h2>Service End Time:</h2>
                                                                <p><?php echo e(date('M d,Y', strtotime($item->scheduled_end_date))); ?>,
                                                                    <?php echo e(date('h:i A', strtotime($item->service_end_time))); ?>

                                                                </p>
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div class="col-md-4">
                                                        <div class="service-shift-card">
                                                            <div class="service-shift-card-image">
                                                                <img
                                                                    src="<?php echo e(asset('public/assets/admin-images/dollar-circle.svg')); ?>">
                                                            </div>
                                                            <div class="service-shift-card-text">
                                                                <h2>Price</h2>
                                                                <p>$<?php echo e($item->total_service_cost); ?> + Tax Included</p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="ongoing-services-item-foot">
                                                <div class="loaction-address"><img
                                                        src="<?php echo e(asset('public/assets/admin-images/map.svg')); ?>"><?php echo e($item->client ? ($item->client ? $item->client->address : '') : 'N/A'); ?>

                                                </div>
                                                <div class="ongoing-services-date">
                                                    <?php echo e(date('l, j M h:i:s A', strtotime($item->created_at))); ?>

                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <div class="ongoing-services-item">
                                            <div class="ongoing-services-item-head">
                                                <div class="ongoing-services-item-title">

                                                    <h2>No Services</h2>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="tab-pane" id="UnAssignedServices">
                                <div class="ongoing-services-list">
                                    <?php $__empty_1 = true; $__currentLoopData = $unassigned; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <div class="ongoing-services-item">
                                            <div class="ongoing-services-item-head">
                                                <div class="ongoing-services-item-title">
                                                    <div class="services-id">#<?php echo e($item->id); ?></div>
                                                    <h2>Service 1: <?php echo e($item->name); ?></h2>
                                                </div>
                                                <div class="ongoing-services-date">
                                                    <?php echo e(date('l, j M h:i:s A', strtotime($item->created_at))); ?></div>
                                            </div>
                                            <div class="ongoing-services-item-body">
                                                <div class="service-shift-card">
                                                    <div class="service-shift-card-image">
                                                        <img
                                                            src="<?php echo e(asset('public/assets/admin-images/calendar-tick.svg')); ?>">
                                                    </div>
                                                    <div class="service-shift-card-text">
                                                        <h2>Service Shift Timing:</h2>
                                                        <p><?php echo e(date('h:i A', strtotime($item->service_start_time))); ?>

                                                            -<?php echo e(date('h:i A', strtotime($item->service_end_time))); ?></p>
                                                    </div>
                                                </div>

                                                <div class="instructions-text">
                                                    <h3><?php echo e($item->description); ?></h3>
                                                </div>

                                                <div class="row">
                                                    <div class="col-md-4">
                                                        <div class="service-shift-card">
                                                            <div class="service-shift-card-image">
                                                                <img
                                                                    src="<?php echo e(asset('public/assets/admin-images/Qty.svg')); ?>">
                                                            </div>
                                                            <div class="service-shift-card-text">
                                                                <h2>Qty:</h2>
                                                                <p>1</p>
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div class="col-md-4">
                                                        <div class="service-shift-card">
                                                            <div class="service-shift-card-image">
                                                                <img
                                                                    src="<?php echo e(asset('public/assets/admin-images/ServiceFrequency.svg')); ?>">
                                                            </div>
                                                            <div class="service-shift-card-text">
                                                                <h2>Service Frequency:</h2>
                                                                <p><?php echo e($item->frequency); ?></p>
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div class="col-md-4">
                                                        <div class="service-shift-card">
                                                            <div class="service-shift-card-image">
                                                                <img
                                                                    src="<?php echo e(asset('public/assets/admin-images/dollar-circle.svg')); ?>">
                                                            </div>
                                                            <div class="service-shift-card-text">
                                                                <h2>Price</h2>
                                                                <p>$<?php echo e($item->total_service_cost); ?>.00 + Tax Included</p>
                                                            </div>
                                                        </div>
                                                    </div>


                                                </div>
                                            </div>
                                            <div class="ongoing-services-item-foot">
                                                <div class="loaction-address"><img
                                                        src="<?php echo e(asset('public/assets/admin-images/map.svg')); ?>"><?php echo e($item->client ? $item->client->address : ''); ?>

                                                </div>
                                                <div class="ongoing-services-action"><a
                                                        href="<?php echo e(route('services.assign', $item->id)); ?>">Assign Team
                                                        Member</a>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <div class="ongoing-services-item">
                                            <div class="ongoing-services-item-head">
                                                <div class="ongoing-services-item-title">

                                                    <h2>No Services</h2>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="tab-pane" id="CompletedServices">
                                <div class="ongoing-services-list">
                                    <?php $__empty_1 = true; $__currentLoopData = $completed; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <div class="ongoing-services-item">
                                            <div class="ongoing-services-item-head">
                                                <div class="ongoing-services-item-title">
                                                    <div class="services-id">#<?php echo e($item->id); ?></div>
                                                    <h2>Service 1: <?php echo e($item->name); ?></h2>
                                                </div>
                                                <div class="client-info">
                                                    <div class="client-info-icon">
                                                        <?php echo e($item->client ? substr($item->client->name, 0, 1) : 'N/A'); ?>

                                                    </div>
                                                    <div class="client-info-text">
                                                        <?php echo e($item->client ? $item->client->name : 'N/A'); ?>

                                                    </div>
                                                </div>

                                            </div>
                                            <div class="ongoing-services-item-body">
                                                <div class="service-shift-card">
                                                    <div class="service-shift-card-image">
                                                        <img
                                                            src="<?php echo e(asset('public/assets/admin-images/calendar-tick.svg')); ?>">
                                                    </div>
                                                    <div class="service-shift-card-text">
                                                        <h2>Service Shift Timing:</h2>
                                                        <p><?php echo e(date('h:i A', strtotime($item->service_start_time))); ?>

                                                            -<?php echo e(date('h:i A', strtotime($item->service_end_time))); ?>

                                                        </p>
                                                    </div>
                                                </div>

                                                <div class="instructions-text">
                                                    <h3>Primary Instructions: <?php echo e($item->description); ?></h3>
                                                </div>

                                                <div class="row">
                                                    <div class="col-md-4">
                                                        <div class="service-shift-card">
                                                            <div class="service-shift-card-image">
                                                                <img
                                                                    src="<?php echo e(asset('public/assets/admin-images/people.svg')); ?>">
                                                            </div>
                                                            <div class="service-shift-card-text">
                                                                <h2>Job Assigned</h2>
                                                                <p>John Doe + <a
                                                                        href="<?php echo e(route('services.assign', $item->id)); ?>">12
                                                                        Employee</a></p>
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div class="col-md-4">
                                                        <div class="service-shift-card">
                                                            <div class="service-shift-card-image">
                                                                <img
                                                                    src="<?php echo e(asset('public/assets/admin-images/ServiceFrequency.svg')); ?>">
                                                            </div>
                                                            <div class="service-shift-card-text">
                                                                <h2>Service Frequency:</h2>
                                                                <p><?php echo e($item->frequency); ?></p>
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div class="col-md-4">
                                                        <div class="service-shift-card">
                                                            <div class="service-shift-card-image">
                                                                <img
                                                                    src="<?php echo e(asset('public/assets/admin-images/buildings.svg')); ?>">
                                                            </div>
                                                            <div class="service-shift-card-text">
                                                                <h2>Service Type:</h2>
                                                                <p><?php echo e($item->service_type); ?></p>
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div class="col-md-4">
                                                        <div class="service-shift-card">
                                                            <div class="service-shift-card-image">
                                                                <img
                                                                    src="<?php echo e(asset('public/assets/admin-images/clock.svg')); ?>">
                                                            </div>
                                                            <div class="service-shift-card-text">
                                                                <h2>Service Start Time:</h2>
                                                                <p><?php echo e(date('M d,Y', strtotime($item->created_date))); ?>,
                                                                    <?php echo e(date('h:i A', strtotime($item->service_start_time))); ?>

                                                                </p>
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div class="col-md-4">
                                                        <div class="service-shift-card">
                                                            <div class="service-shift-card-image">
                                                                <img
                                                                    src="<?php echo e(asset('public/assets/admin-images/clock.svg')); ?>">
                                                            </div>
                                                            <div class="service-shift-card-text">
                                                                <h2>Service End Time:</h2>
                                                                <p><?php echo e(date('M d,Y', strtotime($item->scheduled_end_date))); ?>,
                                                                    <?php echo e(date('h:i A', strtotime($item->service_end_time))); ?>

                                                                </p>
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div class="col-md-4">
                                                        <div class="service-shift-card">
                                                            <div class="service-shift-card-image">
                                                                <img
                                                                    src="<?php echo e(asset('public/assets/admin-images/dollar-circle.svg')); ?>">
                                                            </div>
                                                            <div class="service-shift-card-text">
                                                                <h2>Price</h2>
                                                                <p>$<?php echo e($item->total_service_cost); ?> + Tax Included</p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="ongoing-services-item-foot">
                                                <div class="loaction-address"><img
                                                        src="<?php echo e(asset('public/assets/admin-images/map.svg')); ?>"><?php echo e($item->client ? ($item->client ? $item->client->address : '') : 'N/A'); ?>

                                                </div>
                                                <div class="ongoing-services-date">
                                                    <?php echo e(date('l, j M h:i:s A', strtotime($item->created_at))); ?>

                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <div class="ongoing-services-item">
                                            <div class="ongoing-services-item-head">
                                                <div class="ongoing-services-item-title">

                                                    <h2>No Services</h2>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-3">
                        <div class="service-panel-sidebar">
                            <h2><?php echo e($data->name ?? ''); ?> Ongoing, Assigned & Completed Projects logs</h2>
                            <div class="service-log-media">
                                <img src="<?php echo e(asset('public/assets/admin-images/service-log-icon.svg')); ?>">
                            </div>

                            

                        </div>
                        <div class="team-panel-sidebar">

                            <div class="count-bg-1 mt-2">
                                <p class="p-0 m-0 text-center"><?php echo e(count($ongoing) + count($unassigned)); ?> Total Projects
                                </p>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="detail-small-1 detail-box mt-3">
                                        <h5 class="text-center m-0 p-0"><?php echo e(count($ongoing)); ?></h5>
                                        <p class="text-center mt-2 mb-0 p-0">Ongoing</p>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="detail-small-1 detail-box mt-3">
                                        <h5 class="text-center m-0 p-0"><?php echo e(count($unassigned)); ?></h5>
                                        <p class="text-center mt-2 mb-0 p-0">Un-assigned</p>
                                    </div>
                                </div>
                                <div class="col-md-6 mx-auto">
                                    <div class="detail-small-1 detail-box mt-3">
                                        <h5 class="text-center m-0 p-0"><?php echo e(count($completed)); ?></h5>
                                        <p class="text-center mt-2 mb-0 p-0">Completed</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dlayy048i7m0/public_html/clearchoice-janitorial/resources/views/admin/client-details.blade.php ENDPATH**/ ?>