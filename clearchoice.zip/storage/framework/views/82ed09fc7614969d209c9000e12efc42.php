<?php $__env->startSection('title', 'Clear-ChoiceJanitorial - Client'); ?>
<?php $__env->startPush('css'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(custom_asset('public/assets/admin-css/service.css')); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <div class="body-main-content">
        <div class="ongoing-Services-section">
            <div class="row">
                <div class="col-md-8">
                    <div class="services-tabs">
                        <ul class="nav nav-tabs">
                            <li><a class="active" href="#Ongoing" data-bs-toggle="tab">Ongoing</a></li>
                            <li><a href="#Completed" data-bs-toggle="tab">Completed</a>
                            </li>
                        </ul>
                    </div>
                    <div class="Ongoing-calender-list">
                        <div id="Ongoingcalender" class="owl-carousel owl-theme">
                            <?php
                                $arr = [];
                                // Get the current month and year
                                $currentMonth = now()->format('F');
                                $currentYear = now()->year;

                                // Get the number of days in the current month
                                $daysInMonth = date('j');
                                // Get the current month and year
                                $currentMonth = date('n'); // n represents the month without leading zeros
                                $currentYear = date('Y');

                                // Get the number of days in the current month
                                $numDaysInMonth = cal_days_in_month(CAL_GREGORIAN, $currentMonth, $currentYear);

                                // Loop through each day in the month
                                for ($day = 1; $day <= $numDaysInMonth; $day++) {
                                    $date = now()->setDay($day);
                                    $dayOfWeek = $date->format('D');
                                    $formattedDate = $date->format('d');
                                    $arr[] = ['w' => $dayOfWeek, 'd' => $formattedDate, 'date' => date('Y-m-d', strtotime($date))];
                                }
                            ?>
                            <?php $__currentLoopData = $arr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a class="item" href="<?php echo e(route('services.index', 'date=' . $item['date'])); ?>">
                                    <div class="Ongoing-calender-item">
                                        <h3><?php echo e($item['w']); ?></h3>
                                        <h2><?php echo e($item['d']); ?></h2>
                                    </div>
                                </a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                        </div>
                    </div>
                    <div class="tasks-content-info tab-content">
                        <div class="tab-pane active" id="Ongoing">
                            <div class="ongoing-services-list">
                                <?php $__empty_1 = true; $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <div class="ongoing-services-item">
                                        <div class="ongoing-services-item-head">
                                            <div class="ongoing-services-item-title">
                                                <div class="services-id">#<?php echo e($item->id); ?></div>
                                                <h2 style="cursor: pointer"
                                                    onclick="location.replace('<?php echo e(route('services.edit', $item->id)); ?>')">
                                                    Service 1:
                                                    <?php echo e($item->name); ?></h2>
                                            </div>
                                            <div class="client-info">
                                                <div class="client-info-icon">
                                                    <?php echo e($item->client ? substr($item->client->name, 0, 1) : 'N/A'); ?> </div>
                                                <div class="client-info-text">
                                                    <?php echo e($item->client ? $item->client->name : 'N/A'); ?>

                                                </div>
                                            </div>

                                        </div>
                                        <div class="ongoing-services-item-body">
                                            <div class="service-shift-card">
                                                <div class="service-shift-card-image">
                                                    <img
                                                        src="<?php echo e(custom_asset('public/assets/admin-images/calendar-tick.svg')); ?>">
                                                </div>
                                                <div class="service-shift-card-text">
                                                    <h2>Service Shift Timing:</h2>
                                                    <p><?php echo e(date('h:i A', strtotime($item->service_start_time))); ?>

                                                        - <?php echo e(date('h:i A', strtotime($item->service_end_time))); ?>

                                                    </p>
                                                </div>
                                            </div>

                                            <div class="instructions-text">
                                                <h3>Primary Instructions: <?php echo e($item->description); ?></h3>
                                            </div>

                                            <div class="row">
                                                <div class="col-md-4">
                                                    <div class="service-shift-card">
                                                        <div class="service-shift-card-image">
                                                            <img
                                                                src="<?php echo e(custom_asset('public/assets/admin-images/people.svg')); ?>">
                                                        </div>
                                                        <div class="service-shift-card-text">
                                                            <h2>Job Assigned:</h2>
                                                            <p><?php echo e($item->members->first() ? ($item->members->first()->member ? $item->members->first()->member->fullname : '') : ''); ?>


                                                                <?php if($item->members->count() - 1 > 0): ?>
                                                                    <a href="<?php echo e(route('services.assign', $item->id)); ?>">
                                                                        + <?php echo e($item->members->count() - 1); ?>

                                                                        Employee</a>
                                                                <?php else: ?>
                                                                    <a href="<?php echo e(route('services.assign', $item->id)); ?>"> +

                                                                        Employee</a>
                                                                <?php endif; ?>

                                                            </p>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="col-md-4">
                                                    <div class="service-shift-card">
                                                        <div class="service-shift-card-image">
                                                            <img
                                                                src="<?php echo e(custom_asset('public/assets/admin-images/ServiceFrequency.svg')); ?>">
                                                        </div>
                                                        <div class="service-shift-card-text">
                                                            <h2>Service Frequency:</h2>
                                                            <p><?php echo e($item->frequency); ?></p>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="col-md-4">
                                                    <div class="service-shift-card">
                                                        <div class="service-shift-card-image">
                                                            <img
                                                                src="<?php echo e(custom_asset('public/assets/admin-images/buildings.svg')); ?>">
                                                        </div>
                                                        <div class="service-shift-card-text">
                                                            <h2>Service Type:</h2>
                                                            <p><?php echo e($item->service_type); ?></p>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="col-md-4">
                                                    <div class="service-shift-card">
                                                        <div class="service-shift-card-image">
                                                            <img
                                                                src="<?php echo e(custom_asset('public/assets/admin-images/clock.svg')); ?>">
                                                        </div>
                                                        <div class="service-shift-card-text">
                                                            <h2>Service Start Time:</h2>
                                                            <p><?php echo e(date('M d,Y', strtotime($item->created_date))); ?>,
                                                                <?php echo e(date('h:i A', strtotime($item->service_start_time))); ?>

                                                            </p>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="col-md-4">
                                                    <div class="service-shift-card">
                                                        <div class="service-shift-card-image">
                                                            <img
                                                                src="<?php echo e(custom_asset('public/assets/admin-images/clock.svg')); ?>">
                                                        </div>
                                                        <div class="service-shift-card-text">
                                                            <h2>Service End Time:</h2>
                                                            <p><?php echo e(date('M d,Y', strtotime($item->scheduled_end_date))); ?>

                                                                <?php echo e(date('h:i A', strtotime($item->service_end_time))); ?>

                                                            </p>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="col-md-4">
                                                    <div class="service-shift-card">
                                                        <div class="service-shift-card-image">
                                                            <img
                                                                src="<?php echo e(custom_asset('public/assets/admin-images/dollar-circle.svg')); ?>">
                                                        </div>
                                                        <div class="service-shift-card-text">
                                                            <h2>Price:</h2>
                                                            <p>$<?php echo e($item->total_service_cost); ?> + Tax Included</p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="ongoing-services-item-foot">
                                            <div class="loaction-address"><img
                                                    src="<?php echo e(custom_asset('public/assets/admin-images/map.svg')); ?>"><?php echo e($item->client ? ($item->client ? $item->client->street : '') : 'N/A'); ?>

                                            </div>
                                            <div class="ongoing-services-date">
                                                <?php echo e(date('M d,Y  h:i A', strtotime($item->created_at))); ?>

                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <div class="ongoing-services-item">
                                        <div class="ongoing-services-item-head">
                                            <div class="ongoing-services-item-title">

                                                <h2>No Services</h2>
                                            </div>
                                        </div>
                                    </div>
                                <?php endif; ?>



                            </div>
                        </div>

                        <div class="tab-pane" id="Completed">
                            <div class="ongoing-services-list">
                                <?php $__empty_1 = true; $__currentLoopData = $completed_services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <div class="ongoing-services-item">
                                        <div class="ongoing-services-item-head">
                                            <div class="ongoing-services-item-title">
                                                <div class="services-id">#<?php echo e($item->id); ?></div>
                                                <h2>
                                                    Service 1: <?php echo e($item->name); ?></h2>
                                            </div>
                                            <div class="client-info">
                                                <div class="client-info-icon">
                                                    <?php echo e($item->client ? substr($item->client->name, 0, 1) : 'N/A'); ?> </div>
                                                <div class="client-info-text">
                                                    <?php echo e($item->client ? $item->client->name : 'N/A'); ?>

                                                </div>
                                            </div>

                                        </div>
                                        <div class="ongoing-services-item-body">
                                            <div class="service-shift-card">
                                                <div class="service-shift-card-image">
                                                    <img
                                                        src="<?php echo e(custom_asset('public/assets/admin-images/calendar-tick.svg')); ?>">
                                                </div>
                                                <div class="service-shift-card-text">
                                                    <h2>Service Shift Timing:</h2>
                                                    <p><?php echo e(date('h:i A', strtotime($item->service_start_time))); ?>

                                                        -<?php echo e(date('h:i A', strtotime($item->service_end_time))); ?>

                                                    </p>
                                                </div>
                                            </div>

                                            <div class="instructions-text">
                                                <h3>Primary Instructions: <?php echo e($item->description); ?></h3>
                                            </div>

                                            <div class="row">
                                                <div class="col-md-4">
                                                    <div class="service-shift-card">
                                                        <div class="service-shift-card-image">
                                                            <img
                                                                src="<?php echo e(custom_asset('public/assets/admin-images/people.svg')); ?>">
                                                        </div>
                                                        <div class="service-shift-card-text">
                                                            <h2>Job Assigned:</h2>
                                                            <p><?php echo e($item->members->first() ? ($item->members->first()->member ? $item->members->first()->member->fullname : '') : ''); ?>


                                                                <?php if($item->members->count() - 1 > 0): ?>
                                                                    + <a href="#"><?php echo e($item->members->count() - 1); ?>

                                                                        Employee</a>
                                                                <?php else: ?>
                                                                <?php endif; ?>

                                                            </p>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="col-md-4">
                                                    <div class="service-shift-card">
                                                        <div class="service-shift-card-image">
                                                            <img
                                                                src="<?php echo e(custom_asset('public/assets/admin-images/ServiceFrequency.svg')); ?>">
                                                        </div>
                                                        <div class="service-shift-card-text">
                                                            <h2>Service Frequency:</h2>
                                                            <p><?php echo e($item->frequency); ?></p>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="col-md-4">
                                                    <div class="service-shift-card">
                                                        <div class="service-shift-card-image">
                                                            <img
                                                                src="<?php echo e(custom_asset('public/assets/admin-images/buildings.svg')); ?>">
                                                        </div>
                                                        <div class="service-shift-card-text">
                                                            <h2>Service Type:</h2>
                                                            <p><?php echo e($item->service_type); ?></p>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="col-md-4">
                                                    <div class="service-shift-card">
                                                        <div class="service-shift-card-image">
                                                            <img
                                                                src="<?php echo e(custom_asset('public/assets/admin-images/clock.svg')); ?>">
                                                        </div>
                                                        <div class="service-shift-card-text">
                                                            <h2>Service Start Time:</h2>
                                                            <p><?php echo e(date('M d,Y', strtotime($item->created_date))); ?>,
                                                                <?php echo e(date('h:i A', strtotime($item->service_start_time))); ?>

                                                            </p>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="col-md-4">
                                                    <div class="service-shift-card">
                                                        <div class="service-shift-card-image">
                                                            <img
                                                                src="<?php echo e(custom_asset('public/assets/admin-images/clock.svg')); ?>">
                                                        </div>
                                                        <div class="service-shift-card-text">
                                                            <h2>Service End Time:</h2>
                                                            <p><?php echo e(date('M d,Y', strtotime($item->scheduled_end_date))); ?>

                                                                <?php echo e(date('h:i A', strtotime($item->service_end_time))); ?>

                                                            </p>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="col-md-4">
                                                    <div class="service-shift-card">
                                                        <div class="service-shift-card-image">
                                                            <img
                                                                src="<?php echo e(custom_asset('public/assets/admin-images/dollar-circle.svg')); ?>">
                                                        </div>
                                                        <div class="service-shift-card-text">
                                                            <h2>Price:</h2>
                                                            <p>$<?php echo e($item->total_service_cost); ?> + Tax Included</p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="ongoing-services-item-foot">
                                            <div class="loaction-address"><img
                                                    src="<?php echo e(custom_asset('public/assets/admin-images/map.svg')); ?>"><?php echo e($item->client ? ($item->client ? $item->client->street : '') : 'N/A'); ?>

                                            </div>
                                            <div class="ongoing-services-date">
                                                <?php echo e(date('M d,Y  h:i A', strtotime($item->created_at))); ?>

                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <div class="ongoing-services-item">
                                        <div class="ongoing-services-item-head">
                                            <div class="ongoing-services-item-title">

                                                <h2>No Services</h2>
                                            </div>
                                        </div>
                                    </div>
                                <?php endif; ?>


                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="completedservice-overview">
                        <div class="completedservice-overview-content">
                            <h2>Total Completed Service</h2>
                            <h1><?php echo e($completed); ?></h1>
                            
                        </div>
                        <div class="completedservice-overview-images">
                            <img src="<?php echo e(custom_asset('public/assets/admin-images/service-log-icon.svg')); ?>">
                        </div>
                    </div>

                    <div class="completedservice-overview">
                        <div class="completedservice-overview-content">
                            <h2>Total Earning Amount</h2>
                            <h1>$<?php echo e($earning); ?></h1>
                            
                        </div>
                        <div class="completedservice-overview-images">
                            <img src="<?php echo e(custom_asset('public/assets/admin-images/Earning.svg')); ?>">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dlayy048i7m0/public_html/clearchoice-janitorial/resources/views/admin/services/index.blade.php ENDPATH**/ ?>