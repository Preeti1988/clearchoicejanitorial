<?php $__env->startSection('title', 'Clear-ChoiceJanitorial - Client-Details'); ?>
<?php $__env->startPush('css'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(custom_asset('public/assets/admin-css/team-details.css')); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <div class="body-main-content">
        <div class="client-details-section">
            <div class="client-profile-section">
                <div class="row g-1 align-items-center">
                    <div class="col-md-3">
                        <div class="side-profile-item align-items-center">
                            <div class="side-profile-media"><img
                                    src="<?php echo e(custom_asset('public/assets/admin-images/user-default.png')); ?>"></div>
                            <div class="side-profile-text ms-2">
                                <h2 class="mb-0 pb-0 "><?php echo e($data->fullname ?? ''); ?></h2>
                                <p class="mb-0 pb-0 member-id">Member ID: <b><?php echo e($data->userid ?? ''); ?></b></p>
                                <h6 class="mt-0 pt-0 mb-0 pb-0 join-date">Joined on:
                                    <?php echo e(date('M d, Y', strtotime($data->created_at))); ?></h6>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-9">
                        <div class="row">
                            <div class="col-md-4 d-flex">
                                <div class="client-contact-info align-items-center">
                                    <div class="client-contact-info-icon">
                                        <img src="<?php echo e(custom_asset('public/assets/admin-images/email-icon.svg')); ?>">
                                    </div>
                                    <div class="client-contact-info-content">
                                        <h2>Email Address</h2>
                                        <p><?php echo e($data->email ?? ''); ?></p>
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-3 d-flex">
                                <div class="client-contact-info align-items-center">
                                    <div class="client-contact-info-icon">
                                        <img src="<?php echo e(custom_asset('public/assets/admin-images/phone-icon.svg')); ?>">
                                    </div>
                                    <div class="client-contact-info-content">
                                        <h2>Phone Number</h2>
                                        <p>+<?php echo e($data->country ? $data->country->phonecode : '1'); ?>

                                            <?php echo e($data->phonenumber ?? ''); ?>

                                        </p>
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-3 d-flex">
                                <div class="client-contact-info align-items-center">
                                    <div class="client-contact-info-icon">
                                        <img src="<?php echo e(custom_asset('public/assets/admin-images/career.svg')); ?>">
                                    </div>
                                    <div class="client-contact-info-content">
                                        <h2>Designation: Floor Technician</h2>
                                        <p>Working with 1+ years</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="client-contact-info-content align-items-center">
                                    <h2 class="text-center">Mark as Inactive</h2>
                                    <div class="toggle-btn justify-content-center d-flex">
                                        <input class='input-switch justify-content-center' type="checkbox" id="demo" />
                                        <label class="label-switch" for="demo"></label>
                                        <span class="info-text"></span><br>
                                    </div>
                                    <a href="<?php echo e(custom_asset('public/upload/resume/') . '/' . $data->resume); ?>"
                                        download="<?php echo e($data->resume); ?>" class="resume-btn"><svg
                                            xmlns="http://www.w3.org/2000/svg" width="16" height="16"
                                            fill="currentColor" class="bi bi-arrow-down-square me-2" viewBox="0 0 16 16">
                                            <path fill-rule="evenodd"
                                                d="M15 2a1 1 0 0 0-1-1H2a1 1 0 0 0-1 1v12a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1V2zM0 2a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2V2zm8.5 2.5a.5.5 0 0 0-1 0v5.793L5.354 8.146a.5.5 0 1 0-.708.708l3 3a.5.5 0 0 0 .708 0l3-3a.5.5 0 0 0-.708-.708L8.5 10.293V4.5z" />
                                        </svg>Resume</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


            <div class="ongoing-Services-section">
                <div class="row">
                    <div class="col-md-8">
                        <div class="services-tabs">
                            <ul class="nav nav-tabs">
                                <li><a class="active" href="#Ongoing" data-bs-toggle="tab">Ongoing</a></li>
                                <li><a href="#Completed" data-bs-toggle="tab">Completed</a>
                                </li>
                            </ul>
                        </div>
                        <div class="Ongoing-calender-list">
                            <div id="Ongoingcalender" class="owl-carousel owl-theme">
                                <?php
                                    $arr = [];
                                    // Get the current month and year
                                    $currentMonth = now()->format('F');
                                    $currentYear = now()->year;

                                    // Get the number of days in the current month
                                    $daysInMonth = date('j');
                                    // Get the current month and year
                                    $currentMonth = date('n'); // n represents the month without leading zeros
                                    $currentYear = date('Y');

                                    // Get the number of days in the current month
                                    $numDaysInMonth = cal_days_in_month(CAL_GREGORIAN, $currentMonth, $currentYear);

                                    // Loop through each day in the month
                                    for ($day = 1; $day <= $numDaysInMonth; $day++) {
                                        $date = now()->setDay($day);
                                        $dayOfWeek = $date->format('D');
                                        $formattedDate = $date->format('d');
                                        $arr[] = ['w' => $dayOfWeek, 'd' => $formattedDate, 'date' => date('Y-m-d', strtotime($date))];
                                    }
                                ?>
                                <?php $__currentLoopData = $arr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <a class="item" href="<?php echo e(route('services.index', 'date=' . $item['date'])); ?>">
                                        <div class="Ongoing-calender-item">
                                            <h3><?php echo e($item['w']); ?></h3>
                                            <h2><?php echo e($item['d']); ?></h2>
                                        </div>
                                    </a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                            </div>
                        </div>

                        <div class="tasks-content-info tab-content">
                            <div class="tab-pane active" id="Ongoing">
                                <div class="ongoing-services-list">
                                    <?php $__empty_1 = true; $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <div class="ongoing-services-item">
                                            <div class="ongoing-services-item-head">
                                                <div class="ongoing-services-item-title">
                                                    <div class="services-id">#<?php echo e($item->id); ?></div>
                                                    <h2>Service 1: <?php echo e($item->name); ?></h2>
                                                </div>
                                                <div class="client-info">
                                                    <div class="client-info-icon">
                                                        <?php echo e($item->client ? substr($item->client->name, 0, 1) : 'N/A'); ?>

                                                    </div>
                                                    <div class="client-info-text">
                                                        <?php echo e($item->client ? $item->client->name : 'N/A'); ?>

                                                    </div>
                                                </div>

                                            </div>
                                            <div class="ongoing-services-item-body">
                                                <div class="service-shift-card">
                                                    <div class="service-shift-card-image">
                                                        <img
                                                            src="<?php echo e(custom_asset('public/assets/admin-images/calendar-tick.svg')); ?>">
                                                    </div>
                                                    <div class="service-shift-card-text">
                                                        <h2>Service Shift Timing:</h2>
                                                        <p><?php echo e(date('h:i A', strtotime($item->service_start_time))); ?>

                                                            - <?php echo e(date('h:i A', strtotime($item->service_end_time))); ?>

                                                        </p>
                                                    </div>
                                                </div>

                                                <div class="instructions-text">
                                                    <h3>Primary Instructions: <?php echo e($item->description); ?></h3>
                                                </div>

                                                <div class="row">
                                                    <div class="col-md-4">
                                                        <div class="service-shift-card">
                                                            <div class="service-shift-card-image">
                                                                <img
                                                                    src="<?php echo e(custom_asset('public/assets/admin-images/people.svg')); ?>">
                                                            </div>
                                                            <div class="service-shift-card-text">
                                                                <h2>Job Assigned:</h2>
                                                                <p><?php echo e($item->members->first() ? ($item->members->first()->member ? $item->members->first()->member->fullname : '') : ''); ?>


                                                                    <?php if($item->members->count() - 1 > 0): ?>
                                                                        <a
                                                                            href="<?php echo e(route('services.assign', $item->id)); ?>">
                                                                            + <?php echo e($item->members->count() - 1); ?>

                                                                            Employee</a>
                                                                    <?php else: ?>
                                                                        <a
                                                                            href="<?php echo e(route('services.assign', $item->id)); ?>">
                                                                            +

                                                                            Employee</a>
                                                                    <?php endif; ?>

                                                                </p>
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div class="col-md-4">
                                                        <div class="service-shift-card">
                                                            <div class="service-shift-card-image">
                                                                <img
                                                                    src="<?php echo e(custom_asset('public/assets/admin-images/ServiceFrequency.svg')); ?>">
                                                            </div>
                                                            <div class="service-shift-card-text">
                                                                <h2>Service Frequency:</h2>
                                                                <p><?php echo e($item->frequency); ?></p>
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div class="col-md-4">
                                                        <div class="service-shift-card">
                                                            <div class="service-shift-card-image">
                                                                <img
                                                                    src="<?php echo e(custom_asset('public/assets/admin-images/buildings.svg')); ?>">
                                                            </div>
                                                            <div class="service-shift-card-text">
                                                                <h2>Service Type:</h2>
                                                                <p><?php echo e($item->service_type); ?></p>
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div class="col-md-4">
                                                        <div class="service-shift-card">
                                                            <div class="service-shift-card-image">
                                                                <img
                                                                    src="<?php echo e(custom_asset('public/assets/admin-images/clock.svg')); ?>">
                                                            </div>
                                                            <div class="service-shift-card-text">
                                                                <h2>Service Start Time:</h2>
                                                                <p><?php echo e(date('M d,Y', strtotime($item->created_date))); ?>,
                                                                    <?php echo e(date('h:i A', strtotime($item->service_start_time))); ?>

                                                                </p>
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div class="col-md-4">
                                                        <div class="service-shift-card">
                                                            <div class="service-shift-card-image">
                                                                <img
                                                                    src="<?php echo e(custom_asset('public/assets/admin-images/clock.svg')); ?>">
                                                            </div>
                                                            <div class="service-shift-card-text">
                                                                <h2>Service End Time:</h2>
                                                                <p><?php echo e(date('M d,Y', strtotime($item->scheduled_end_date))); ?>

                                                                    <?php echo e(date('h:i A', strtotime($item->service_end_time))); ?>

                                                                </p>
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div class="col-md-4">
                                                        <div class="service-shift-card">
                                                            <div class="service-shift-card-image">
                                                                <img
                                                                    src="<?php echo e(custom_asset('public/assets/admin-images/dollar-circle.svg')); ?>">
                                                            </div>
                                                            <div class="service-shift-card-text">
                                                                <h2>Price:</h2>
                                                                <p>$<?php echo e($item->total_service_cost); ?> + Tax Included</p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="ongoing-services-item-foot">
                                                <div class="loaction-address"><img
                                                        src="<?php echo e(custom_asset('public/assets/admin-images/map.svg')); ?>"><?php echo e($item->client ? ($item->client ? $item->client->street : '') : 'N/A'); ?>

                                                </div>
                                                <div class="ongoing-services-date">
                                                    <?php echo e(date('M d,Y  h:i A', strtotime($item->created_at))); ?>

                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <div class="ongoing-services-item">
                                            <div class="ongoing-services-item-head">
                                                <div class="ongoing-services-item-title">

                                                    <h2>No Services</h2>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endif; ?>



                                </div>
                            </div>

                            <div class="tab-pane" id="Completed">
                                <div class="ongoing-services-list">
                                    <?php $__empty_1 = true; $__currentLoopData = $completed_services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <div class="ongoing-services-item">
                                            <div class="ongoing-services-item-head">
                                                <div class="ongoing-services-item-title">
                                                    <div class="services-id">#<?php echo e($item->id); ?></div>
                                                    <h2>Service 1: <?php echo e($item->name); ?></h2>
                                                </div>
                                                <div class="client-info">
                                                    <div class="client-info-icon">
                                                        <?php echo e($item->client ? substr($item->client->name, 0, 1) : 'N/A'); ?>

                                                    </div>
                                                    <div class="client-info-text">
                                                        <?php echo e($item->client ? $item->client->name : 'N/A'); ?>

                                                    </div>
                                                </div>

                                            </div>
                                            <div class="ongoing-services-item-body">
                                                <div class="service-shift-card">
                                                    <div class="service-shift-card-image">
                                                        <img
                                                            src="<?php echo e(custom_asset('public/assets/admin-images/calendar-tick.svg')); ?>">
                                                    </div>
                                                    <div class="service-shift-card-text">
                                                        <h2>Service Shift Timing:</h2>
                                                        <p><?php echo e(date('h:i A', strtotime($item->service_start_time))); ?>

                                                            -<?php echo e(date('h:i A', strtotime($item->service_end_time))); ?>

                                                        </p>
                                                    </div>
                                                </div>

                                                <div class="instructions-text">
                                                    <h3>Primary Instructions: <?php echo e($item->description); ?></h3>
                                                </div>

                                                <div class="row">
                                                    <div class="col-md-4">
                                                        <div class="service-shift-card">
                                                            <div class="service-shift-card-image">
                                                                <img
                                                                    src="<?php echo e(custom_asset('public/assets/admin-images/people.svg')); ?>">
                                                            </div>
                                                            <div class="service-shift-card-text">
                                                                <h2>Job Assigned:</h2>
                                                                <p><?php echo e($item->members->first() ? ($item->members->first()->member ? $item->members->first()->member->fullname : '') : ''); ?>


                                                                    <?php if($item->members->count() - 1): ?>
                                                                        + <a
                                                                            href="<?php echo e(route('services.assign', $item->id)); ?>"><?php echo e($item->members->count() - 1); ?>

                                                                            Employee</a>
                                                                    <?php else: ?>
                                                                        <a
                                                                            href="<?php echo e(route('services.assign', $item->id)); ?>">+
                                                                            Employee</a>
                                                                    <?php endif; ?>

                                                                </p>
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div class="col-md-4">
                                                        <div class="service-shift-card">
                                                            <div class="service-shift-card-image">
                                                                <img
                                                                    src="<?php echo e(custom_asset('public/assets/admin-images/ServiceFrequency.svg')); ?>">
                                                            </div>
                                                            <div class="service-shift-card-text">
                                                                <h2>Service Frequency:</h2>
                                                                <p><?php echo e($item->frequency); ?></p>
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div class="col-md-4">
                                                        <div class="service-shift-card">
                                                            <div class="service-shift-card-image">
                                                                <img
                                                                    src="<?php echo e(custom_asset('public/assets/admin-images/buildings.svg')); ?>">
                                                            </div>
                                                            <div class="service-shift-card-text">
                                                                <h2>Service Type:</h2>
                                                                <p><?php echo e($item->service_type); ?></p>
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div class="col-md-4">
                                                        <div class="service-shift-card">
                                                            <div class="service-shift-card-image">
                                                                <img
                                                                    src="<?php echo e(custom_asset('public/assets/admin-images/clock.svg')); ?>">
                                                            </div>
                                                            <div class="service-shift-card-text">
                                                                <h2>Service Start Time:</h2>
                                                                <p><?php echo e(date('M d,Y', strtotime($item->created_date))); ?>,
                                                                    <?php echo e(date('h:i A', strtotime($item->service_start_time))); ?>

                                                                </p>
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div class="col-md-4">
                                                        <div class="service-shift-card">
                                                            <div class="service-shift-card-image">
                                                                <img
                                                                    src="<?php echo e(custom_asset('public/assets/admin-images/clock.svg')); ?>">
                                                            </div>
                                                            <div class="service-shift-card-text">
                                                                <h2>Service End Time:</h2>
                                                                <p><?php echo e(date('M d,Y', strtotime($item->scheduled_end_date))); ?>

                                                                    <?php echo e(date('h:i A', strtotime($item->service_end_time))); ?>

                                                                </p>
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div class="col-md-4">
                                                        <div class="service-shift-card">
                                                            <div class="service-shift-card-image">
                                                                <img
                                                                    src="<?php echo e(custom_asset('public/assets/admin-images/dollar-circle.svg')); ?>">
                                                            </div>
                                                            <div class="service-shift-card-text">
                                                                <h2>Price:</h2>
                                                                <p>$<?php echo e($item->total_service_cost); ?> + Tax Included</p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="ongoing-services-item-foot">
                                                <div class="loaction-address"><img
                                                        src="<?php echo e(custom_asset('public/assets/admin-images/map.svg')); ?>"><?php echo e($item->client ? ($item->client ? $item->client->street : '') : 'N/A'); ?>

                                                </div>
                                                <div class="ongoing-services-date">
                                                    <?php echo e(date('M d,Y  h:i A', strtotime($item->created_at))); ?>

                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <div class="ongoing-services-item">
                                            <div class="ongoing-services-item-head">
                                                <div class="ongoing-services-item-title">

                                                    <h2>No Services</h2>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endif; ?>


                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-4">
                        <div class="team-panel-sidebar side-bar-1">
                            <h6 class="mb-0 pb-0">This Week Worked </h6>
                            <p class="hour-info text-center mt-0"><?php echo e($this_week); ?> </p>
                            <h6 class="mb-0 pb-0 mt-3">Total Assigned Service Worked </h6>
                            <p class="hour-info text-center mt-0"><?php echo e($total_hours); ?></p>

                        </div>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- -----------------view map modal------------------ -->
    <div class="modal fade view-map" id="view-map" tabindex="-1" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div class="name-info">
                            <h5 class="mb-0 pb-0">Jane Doe</h5>
                            <p class="mb-0 pb-0 mt-0 pt-0">Location log</p>
                        </div>
                        <div class="d-flex">
                            <a href="#" class="check-in-btn">Check in: 11:04 PM</a>
                            <a href="#" class="check-out-btn ms-3">Check out: 11:04 PM</a>
                        </div>
                    </div>
                    <div class="map-detail mt-3">
                        <img src="<?php echo e(custom_asset('public/assets/admin-images/map-info-image.svg')); ?>" alt="image"
                            class="img-fluid">
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dlayy048i7m0/public_html/clearchoice-janitorial/resources/views/admin/teams/show.blade.php ENDPATH**/ ?>