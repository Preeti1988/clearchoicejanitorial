<?php if($datas->isEmpty()): ?>
<tr>
    <td colspan="11" class="text-center">
        No record found
    </td>
</tr>
<?php elseif(!$datas->isEmpty()): ?>
<?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php $sno = 1; ?>
<div class="team-info-box mb-2">
    <div class="row align-items-center">
        <div class="col-md-1">
            <p class="mb-0">Emp ID</p>
            <h6 class="mt-1"><?php echo e($sno); ?></h6>
        </div>
        <div class="col-md-3">
            <div class="d-flex align-items-center">
                <div class="profile-img">
                    <img src="<?php echo e(asset('public/assets/admin-images/profile-img.jpg')); ?>" alt="image" class="img-fluid">
                </div>
                <h6 class="ms-2 mt-0 mb-0"><?php echo e(($val->fullname) ?? ''); ?></h6>
            </div>
        </div>
        <div class="col-md-3">
            <p class="mb-0">Email Id</p>
            <h6 class="mt-1"><?php echo e($val->email); ?></h6>
        </div>
        <div class="col-md-2">
            <p class="mb-0">Phone no.</p>
            <h6 class="mt-1">+<?php echo e(CountryCode($val->country_id)); ?> <?php echo e($val->phonenumber); ?></h6>
        </div>
        <div class="col-md-2">
            <p class="mb-0">Mark as Inactive</p>
            <input class='input-switch justify-content-end' type="checkbox" id="demo" />
            <label class="label-switch" for="demo"></label>
            <span class="info-text"></span>
        </div>
        <div class="col-md-1 ">
            <div class="view-btn">
                <a href="<?php echo e(url('team-detail/'.encryptDecrypt('encrypt',$val->userid))); ?>">
                    <h6><i class="fa fa-eye me-1"></i>View</h6>
                </a>
            </div>
        </div>
    </div>
</div>
<?php $sno++; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?><?php /**PATH /home/dlayy048i7m0/public_html/clearchoice-janitorial/resources/views/admin/team-active.blade.php ENDPATH**/ ?>